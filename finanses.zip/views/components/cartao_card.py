import flet as ft
import flet_charts as fch


def criar_card_cartao(
    page_ref: ft.Page,
    cartao,
    mes_sel: int,
    ano_sel: int,
    transacoes_todas: list,
    mapa_cartoes: dict,
    on_atualizar_dados,
    formatar_moeda_func,
    mostrar_mensagem_func,
    obter_ou_criar_fatura_mensal_func,
    atualizar_status_fatura_func,
    calcular_limites_cartao_func,
    projetar_faturas_futuras_func,
    obter_mes_ano_fatura_func,
    MESES_LISTA
):
    """Constrói o card individual estilizado para um cartão de crédito específico."""
    
    # Filtra transações do cartão atual no mês selecionado
    tc_cartao_atual = []
    for tc in transacoes_todas:
        if getattr(tc, "cartao_id", None) == cartao.id or (hasattr(tc, "cartao") and tc.cartao and tc.cartao.id == cartao.id):
            tc_dt = getattr(tc, "data", None) or getattr(tc, "data_dt", None)
            if not tc_dt:
                continue
            
            dia_fechamento = cartao.dia_fechamento
            mes_fatura, ano_fatura = obter_mes_ano_fatura_func(
                tc_dt, dia_fechamento, tc.tipo
            )
            if mes_fatura == mes_sel and ano_fatura == ano_sel:
                tc_cartao_atual.append(tc)

    compras_cartao = sum(tc.valor for tc in tc_cartao_atual if tc.tipo == "Saída")
    pagamentos_cartao = sum(tc.valor for tc in tc_cartao_atual if tc.tipo == "Entrada")
    fatura_cartao = max(0.0, compras_cartao - pagamentos_cartao)

    lims_cartao = calcular_limites_cartao_func(cartao.id)
    t_total = lims_cartao["total"]
    t_comp = lims_cartao["comprometido"]
    t_disp = lims_cartao["disponivel"]

    perc_c = (t_comp / t_total) if t_total > 0 else 0.0
    cor_c = (
        ft.Colors.GREEN_400 if perc_c < 0.7 
        else (ft.Colors.AMBER_400 if perc_c < 0.9 else ft.Colors.RED_400)
    )

    # Gráfico circular individual utilizando flet_charts (fch)
    chart_indiv = fch.PieChart(
        sections=[
            fch.PieChartSection(
                value=compras_cartao if compras_cartao > 0 else 0.001,
                title=f"Gastos\n{formatar_moeda_func(compras_cartao)}",
                color=ft.Colors.RED_400,
                radius=28,
                title_style=ft.TextStyle(size=8, weight=ft.FontWeight.BOLD, color=ft.Colors.WHITE),
            ),
            fch.PieChartSection(
                value=pagamentos_cartao if pagamentos_cartao > 0 else 0.001,
                title=f"Abatimento\n{formatar_moeda_func(pagamentos_cartao)}",
                color=ft.Colors.GREEN_400,
                radius=28,
                title_style=ft.TextStyle(size=8, weight=ft.FontWeight.BOLD, color=ft.Colors.WHITE),
            ),
        ] if (compras_cartao > 0 or pagamentos_cartao > 0) else [
            fch.PieChartSection(
                value=1.0,
                title="Sem gastos",
                color=ft.Colors.GREY_700,
                radius=28,
                title_style=ft.TextStyle(size=8, color=ft.Colors.WHITE),
            )
        ],
        sections_space=2,
        center_space_radius=18,
    )

    # Status da Fatura
    fatura_mensal = obter_ou_criar_fatura_mensal_func(cartao.id, mes_sel, ano_sel)
    status_atual = fatura_mensal.status

    def alterar_status_fatura(e):
        novo_status = e.control.value
        atualizar_status_fatura_func(cartao.id, mes_sel, ano_sel, novo_status)
        mostrar_mensagem_func(page_ref, f"✅ Status alterado para: {novo_status}")
        on_atualizar_dados()

    dropdown_status = ft.Dropdown(
        value=status_atual,
        options=[
            ft.dropdown.Option("Aberta"),
            ft.dropdown.Option("Fechada"),
            ft.dropdown.Option("Paga"),
        ],
        width=115,
        text_size=11,
        content_padding=ft.Padding(left=8, right=8, top=2, bottom=2),
        on_select=alterar_status_fatura,
    )

    def pagar_fatura_acao(e):
        if fatura_cartao <= 0:
            mostrar_mensagem_func(page_ref, "⚠️ Esta fatura não possui saldo devedor.")
            return
        atualizar_status_fatura_func(cartao.id, mes_sel, ano_sel, "Paga")
        mostrar_mensagem_func(page_ref, f"✅ Fatura de {formatar_moeda_func(fatura_cartao)} marcada como Paga!")
        on_atualizar_dados()

    btn_pagar = ft.FilledButton(
        "Pagar",
        icon=ft.Icons.CHECK_CIRCLE_OUTLINE,
        icon_color=ft.Colors.GREEN_400,
        scale=0.85,
        on_click=pagar_fatura_acao,
    )

    # Projeção de Faturas Futuras
    projecoes = projetar_faturas_futuras_func(transacoes_todas, cartao.id, qtd_meses=3)
    linhas_projecao = []
    for (ano_p, mes_p), val_p in projecoes.items():
        nome_m = MESES_LISTA[mes_p - 1][1] if isinstance(MESES_LISTA[mes_p - 1], tuple) else str(MESES_LISTA[mes_p - 1])
        linhas_projecao.append(
            ft.Row(
                [
                    ft.Text(f"{nome_m}/{ano_p}", size=11, color=ft.Colors.GREY_300),
                    ft.Text(formatar_moeda_func(val_p), size=11, weight=ft.FontWeight.BOLD, color=ft.Colors.AMBER_300),
                ],
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            )
        )

    bloco_projecao = ft.Container(
        content=ft.Column(
            [
                ft.Text("Projeção de Faturas Futuras", size=11, weight=ft.FontWeight.BOLD, color=ft.Colors.BLUE_200),
                ft.Column(linhas_projecao, spacing=2),
            ],
            spacing=4,
        ),
        padding=8,
        bgcolor=ft.Colors.WHITE_10,
        border_radius=6,
    )

    return ft.Container(
        content=ft.Column([
            ft.Row([
                ft.Text(f"Cartão: {cartao.nome}", size=14, weight=ft.FontWeight.BOLD),
                ft.Text(f"Fatura: {formatar_moeda_func(fatura_cartao)}", size=12, color=ft.Colors.AMBER_400, weight=ft.FontWeight.BOLD),
            ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
            ft.Row([
                ft.Text("Status:", size=11, color=ft.Colors.GREY_300),
                dropdown_status,
            ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
            
            # Container com tamanho fixo garantido para o gráfico do flet_charts
            ft.Container(
                content=chart_indiv,
                width=290,
                height=110,
                alignment=ft.Alignment(0, 0),
            ),
            
            ft.Divider(height=1, color=ft.Colors.WHITE_12),
            ft.Column([
                ft.Row([
                    ft.Text(f"Limite ({perc_c*100:.1f}% usado)", size=11, color=ft.Colors.GREY_300),
                    ft.Text(f"Total: {formatar_moeda_func(t_total)}", size=11, color=ft.Colors.GREY_400),
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                ft.ProgressBar(value=min(1.0, perc_c), color=cor_c, bgcolor=ft.Colors.WHITE_10, height=6),
                ft.Row([
                    ft.Text(f"Disp: {formatar_moeda_func(t_disp)}", color=ft.Colors.GREEN_400, size=10, weight=ft.FontWeight.BOLD),
                    ft.Text(f"Usado: {formatar_moeda_func(t_comp)}", color=ft.Colors.RED_400, size=10),
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
            ], spacing=3),
            
            ft.Divider(height=1, color=ft.Colors.WHITE_12),
            bloco_projecao,
            ft.Row([btn_pagar], alignment=ft.MainAxisAlignment.END),
        ], spacing=6),
        padding=12,
        border=ft.Border.all(1, ft.Colors.WHITE_24),
        border_radius=10,
        width=320,
    )