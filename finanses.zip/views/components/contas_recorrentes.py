from datetime import date

import flet as ft
import flet_charts as fch

from database.crud import (
    alternar_pagamento_conta,
    remover_conta_recorrente,
    salvar_conta_recorrente,
)
from services.contas_service import parcelas_restantes
from utils.ui_helpers import mostrar_mensagem

FORMAS_PAGAMENTO_CONTA = ["PIX", "Débito", "Dinheiro"]


def _percentual_br(valor: float) -> str:
    return f"{valor:.1f}".replace(".", ",") + "%"


def _interpretar_valor(texto) -> float:
    """Converte '1.234,56', '1234,56' ou '1234.56' em float."""
    s = str(texto or "").replace("R$", "").replace(" ", "").strip()
    if "," in s:
        s = s.replace(".", "").replace(",", ".")
    return float(s)


class GraficoRendaComprometida(ft.Container):
    """Gráfico 'valor / renda comprometida': contas pagas, a pagar e renda livre."""

    def __init__(self, formatar_moeda_func):
        super().__init__(
            padding=15,
            height=290,
            border=ft.Border.all(1, ft.Colors.WHITE_24),
            border_radius=10,
            expand=True,
        )
        self.formatar = formatar_moeda_func

        self.chart = fch.PieChart(sections=[], sections_space=2, center_space_radius=35)
        self.txt_resumo = ft.Text(
            "R$ 0,00 / R$ 0,00", size=14, weight=ft.FontWeight.BOLD, color=ft.Colors.AMBER_400
        )
        self.txt_detalhe = ft.Text("", size=11, color=ft.Colors.GREY_400)

        self.content = ft.Column(
            [
                ft.Text("Renda comprometida", size=15, weight=ft.FontWeight.BOLD),
                ft.Container(
                    content=self.chart, width=300, height=170, alignment=ft.Alignment(0, 0)
                ),
                self.txt_resumo,
                self.txt_detalhe,
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=4,
        )

    def atualizar(self, c: dict):
        fmt = self.formatar
        total_pizza = c["pagas"] + c["pendentes"] + c["livre"]

        fatias = []
        for rotulo, valor, cor in (
            ("Pagas", c["pagas"], ft.Colors.GREEN_400),
            ("A pagar", c["pendentes"], ft.Colors.AMBER_400),
            ("Livre", c["livre"], ft.Colors.BLUE_400),
        ):
            if valor > 0:
                fatias.append(
                    fch.PieChartSection(
                        value=valor,
                        title=f"{rotulo}\n{valor / total_pizza * 100:.0f}%",
                        color=cor,
                        radius=50,
                        title_style=ft.TextStyle(
                            size=11, weight=ft.FontWeight.BOLD, color=ft.Colors.WHITE
                        ),
                    )
                )
        if not fatias:
            fatias = [
                fch.PieChartSection(
                    value=1.0,
                    title="Sem contas",
                    color=ft.Colors.GREY_700,
                    radius=50,
                    title_style=ft.TextStyle(size=11, color=ft.Colors.WHITE),
                )
            ]
        self.chart.sections = fatias

        self.txt_resumo.value = f"{fmt(c['total_contas'])} / {fmt(c['renda'])}"
        if c["total_contas"] <= 0:
            detalhe = "Nenhuma conta recorrente neste mês"
        elif c["percentual"] is None:
            detalhe = "Sem renda lançada neste mês"
        else:
            detalhe = f"{_percentual_br(c['percentual'])} da renda comprometida"
        self.txt_detalhe.value = (
            f"{detalhe}\nPagas {fmt(c['pagas'])}  ·  A pagar {fmt(c['pendentes'])}"
        )


class AbaContasRecorrentes(ft.Container):
    """Aba para cadastrar contas fixas e marcá-las como pagas mês a mês."""

    def __init__(self, page_ref, perfil_ativo_id, obter_periodo, on_atualizar, formatar_moeda_func):
        super().__init__(padding=10, visible=False, expand=True)
        self.page_ref = page_ref
        self.perfil_ativo_id = perfil_ativo_id
        self.obter_periodo = obter_periodo  # função que devolve (mes, ano) dos filtros
        self.on_atualizar = on_atualizar  # recarrega o dashboard inteiro
        self.formatar = formatar_moeda_func
        self.conta_em_edicao_id = None

        self.txt_descricao = ft.TextField(
            label="Descrição", hint_text="Ex: Aluguel, Internet...", expand=True, on_submit=self.salvar
        )
        self.txt_valor = ft.TextField(
            label="Valor (R$)", width=140, keyboard_type=ft.KeyboardType.NUMBER, on_submit=self.salvar
        )
        self.txt_dia = ft.TextField(
            label="Dia do venc.", hint_text="1 a 31", width=120,
            keyboard_type=ft.KeyboardType.NUMBER, on_submit=self.salvar,
        )
        self.txt_parcelas = ft.TextField(
            label="Nº de parcelas", hint_text="vazio = sem fim", width=150,
            keyboard_type=ft.KeyboardType.NUMBER, on_submit=self.salvar,
        )
        self.txt_parcela_mes = ft.TextField(
            label="Parcela deste mês", hint_text="1", width=150,
            keyboard_type=ft.KeyboardType.NUMBER, on_submit=self.salvar,
        )
        self.dropdown_forma = ft.Dropdown(
            label="Pagamento", width=140, value="PIX",
            options=[ft.dropdown.Option(f) for f in FORMAS_PAGAMENTO_CONTA],
        )
        self.btn_salvar = ft.FilledButton(
            "Salvar conta", icon=ft.Icons.SAVE, height=48,
            bgcolor=ft.Colors.BLUE_600, color=ft.Colors.WHITE, on_click=self.salvar,
        )
        self.btn_cancelar = ft.TextButton(
            "Cancelar edição", visible=False, on_click=self.cancelar_edicao
        )

        self.txt_modo = ft.Text("", size=12, color=ft.Colors.AMBER_300)
        self.txt_totais = ft.Text("", size=12, color=ft.Colors.GREY_400)
        self.txt_vazio = ft.Text(
            "Nenhuma conta recorrente neste mês. Cadastre a primeira acima.",
            size=12, color=ft.Colors.GREY_500, visible=False,
        )
        self.tabela = ft.DataTable(
            columns=[
                ft.DataColumn(ft.Text(c))
                for c in ["Pago?", "Vencimento", "Descrição", "Parcela", "Pagamento", "Valor", "Ações"]
            ],
            rows=[],
            expand=True,
        )

        self.content = ft.Column(
            [
                ft.Text("Contas Recorrentes", size=18, weight=ft.FontWeight.BOLD),
                ft.Text(
                    "Cadastre contas fixas (aluguel, internet...) ou parcelamentos: informe o nº total "
                    "de parcelas e em qual parcela você está neste mês. Ao marcar como paga, a conta "
                    "vira uma saída nos lançamentos do mês.",
                    size=12, color=ft.Colors.GREY_400,
                ),
                ft.Row(
                    [self.txt_descricao, self.txt_valor, self.txt_dia, self.dropdown_forma],
                    spacing=8, vertical_alignment=ft.CrossAxisAlignment.CENTER,
                ),
                ft.Row(
                    [self.txt_parcelas, self.txt_parcela_mes, self.btn_salvar, self.btn_cancelar],
                    spacing=8, vertical_alignment=ft.CrossAxisAlignment.CENTER,
                ),
                self.txt_modo,
                ft.Divider(),
                self.txt_totais,
                self.txt_vazio,
                self.tabela,
            ],
            expand=True, scroll=ft.ScrollMode.AUTO, spacing=10,
        )

    # ---------- exibição ----------
    def atualizar(self, dados: dict):
        """Preenche a tabela com as contas do mês selecionado."""
        fmt = self.formatar
        hoje = date.today()
        linhas = []

        for c in dados["contas_mes"]:
            atrasada = (not c["pago"]) and c["vencimento"] < hoje
            chk = ft.Checkbox(
                value=c["pago"],
                tooltip="Marcar como paga",
                on_change=lambda e, cid=c["id"]: self._ao_marcar_pago(cid, e.control.value),
            )
            btn_edit = ft.IconButton(
                icon=ft.Icons.EDIT_OUTLINED, icon_color=ft.Colors.BLUE_400, tooltip="Editar",
                on_click=lambda e, conta=c: self._editar(conta),
            )
            btn_del = ft.IconButton(
                icon=ft.Icons.DELETE_OUTLINED, icon_color=ft.Colors.GREY_500, tooltip="Excluir conta",
                on_click=lambda e, cid=c["id"]: self._excluir(cid),
            )
            linhas.append(
                ft.DataRow(
                    cells=[
                        ft.DataCell(chk),
                        ft.DataCell(
                            ft.Text(
                                c["vencimento"].strftime("%d/%m/%Y") + (" (atrasada)" if atrasada else ""),
                                color=ft.Colors.RED_400 if atrasada else None,
                            )
                        ),
                        ft.DataCell(ft.Text(c["descricao"])),
                        ft.DataCell(ft.Text(self._texto_parcela(c))),
                        ft.DataCell(ft.Text(c["forma_pagamento"] or "-")),
                        ft.DataCell(
                            ft.Text(
                                fmt(c["valor_efetivo"]),
                                color=ft.Colors.GREEN_400 if c["pago"] else ft.Colors.AMBER_400,
                            )
                        ),
                        ft.DataCell(ft.Row([btn_edit, btn_del], spacing=0)),
                    ]
                )
            )

        self.tabela.rows = linhas
        self.txt_vazio.visible = not linhas

        comp = dados["comprometimento"]
        self.txt_totais.value = (
            f"Pagas: {fmt(comp['pagas'])}   |   A pagar: {fmt(comp['pendentes'])}"
            f"   |   Total do mês: {fmt(comp['total_contas'])}"
        )
        falta_parcelamentos = sum(
            parcelas_restantes(c["numero_parcela"], c["total_parcelas"], c["pago"]) * c["valor"]
            for c in dados["contas_mes"]
            if c["total_parcelas"]
        )
        if falta_parcelamentos > 0:
            self.txt_totais.value += f"   |   Falta pagar nos parcelamentos: {fmt(falta_parcelamentos)}"

    @staticmethod
    def _texto_parcela(conta: dict) -> str:
        if conta["total_parcelas"]:
            return f"{conta['numero_parcela']}/{conta['total_parcelas']}"
        return "—"

    # ---------- ações ----------
    def limpar_formulario(self):
        self.conta_em_edicao_id = None
        self.txt_descricao.value = ""
        self.txt_valor.value = ""
        self.txt_dia.value = ""
        self.txt_parcelas.value = ""
        self.txt_parcela_mes.value = ""
        self.dropdown_forma.value = "PIX"
        self.btn_cancelar.visible = False
        self.txt_modo.value = ""

    def cancelar_edicao(self, e=None):
        self.limpar_formulario()
        self.page_ref.update()

    def _editar(self, conta: dict):
        self.conta_em_edicao_id = conta["id"]
        self.txt_descricao.value = conta["descricao"]
        self.txt_valor.value = f"{conta['valor']:.2f}".replace(".", ",")
        self.txt_dia.value = str(conta["dia_vencimento"])
        self.txt_parcelas.value = str(conta["total_parcelas"]) if conta["total_parcelas"] else ""
        self.txt_parcela_mes.value = str(conta["numero_parcela"]) if conta["total_parcelas"] else ""
        self.dropdown_forma.value = conta["forma_pagamento"] or "PIX"
        self.btn_cancelar.visible = True
        self.txt_modo.value = f"Editando: {conta['descricao']} (vale para os meses ainda não pagos)"
        self.page_ref.update()

    def salvar(self, e=None):
        perfil_id = self.perfil_ativo_id[0]
        if not perfil_id:
            mostrar_mensagem(self.page_ref, "❌ Selecione um perfil primeiro!")
            return

        descricao = (self.txt_descricao.value or "").strip()
        try:
            valor = _interpretar_valor(self.txt_valor.value)
            dia = int((self.txt_dia.value or "").strip())
            txt_total = (self.txt_parcelas.value or "").strip()
            txt_parcela = (self.txt_parcela_mes.value or "").strip()
            total_parcelas = int(txt_total) if txt_total else None
            parcela_mes = int(txt_parcela) if txt_parcela else 1
        except ValueError:
            mostrar_mensagem(
                self.page_ref,
                "❌ Informe valor, dia de vencimento e parcelas válidos (use só números)!",
            )
            return

        if not descricao or valor <= 0 or not 1 <= dia <= 31:
            mostrar_mensagem(
                self.page_ref,
                "❌ Preencha a descrição, um valor maior que zero e um dia entre 1 e 31!",
            )
            return

        mes, ano = self.obter_periodo()
        editando = self.conta_em_edicao_id is not None
        try:
            salvar_conta_recorrente(
                descricao=descricao,
                valor=valor,
                dia_vencimento=dia,
                forma_pagamento=self.dropdown_forma.value or "PIX",
                perfil_id=perfil_id,
                mes_inicio=mes,
                ano_inicio=ano,
                conta_id=self.conta_em_edicao_id,
                total_parcelas=total_parcelas,
                parcela_mes=parcela_mes,
            )
        except Exception as ex:
            mostrar_mensagem(self.page_ref, f"❌ Erro ao salvar conta: {ex}")
            return

        self.limpar_formulario()
        mostrar_mensagem(
            self.page_ref, "✅ Conta atualizada!" if editando else "✅ Conta cadastrada!"
        )
        self.on_atualizar()

    def _ao_marcar_pago(self, conta_id: int, pago: bool):
        mes, ano = self.obter_periodo()
        try:
            alternar_pagamento_conta(conta_id, mes, ano, bool(pago))
            mostrar_mensagem(
                self.page_ref,
                "✅ Conta paga! Lançada como saída no mês." if pago else "↩️ Pagamento desfeito.",
            )
        except Exception as ex:
            mostrar_mensagem(self.page_ref, f"❌ Erro ao atualizar pagamento: {ex}")
        self.on_atualizar()

    def _excluir(self, conta_id: int):
        try:
            remover_conta_recorrente(conta_id)
            if self.conta_em_edicao_id == conta_id:
                self.limpar_formulario()
            mostrar_mensagem(self.page_ref, "✅ Conta removida! Lançamentos já pagos foram mantidos.")
        except Exception as ex:
            mostrar_mensagem(self.page_ref, f"❌ Erro ao remover conta: {ex}")
        self.on_atualizar()
