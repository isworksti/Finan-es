from datetime import date
from dateutil.relativedelta import relativedelta

def obter_mes_ano_fatura(data_transacao: date, dia_fechamento: int = None, tipo: str = "Saída"):
    """
    Calcula em qual mês/ano de fatura a transação irá cair com base 
    no dia de fechamento do cartão.

    REGRA ÚNICA do app: compras feitas até o dia de fechamento (inclusive)
    entram na fatura do próprio mês; compras feitas depois do dia de
    fechamento entram na fatura do mês seguinte.
    """
    if not dia_fechamento:
        return data_transacao.month, data_transacao.year

    # Se a compra foi feita após o dia de fechamento, ela vai para o mês seguinte
    if data_transacao.day > dia_fechamento:
        data_fatura = data_transacao + relativedelta(months=1)
    else:
        data_fatura = data_transacao

    return data_fatura.month, data_fatura.year


def filtrar_transacoes_fatura(transacoes, mes_alvo, ano_alvo, dia_fechamento=None):
    """
    Filtra as transações que pertencem a uma fatura específica (mês/ano)
    considerando o dia de fechamento do cartão.
    """
    filtradas = []
    for t in transacoes:
        t_dt = getattr(t, "data", None) or getattr(t, "data_dt", None)
        if not t_dt:
            continue
        
        m_fat, a_fat = obter_mes_ano_fatura(t_dt, dia_fechamento, getattr(t, "tipo", "Saída"))
        if m_fat == mes_alvo and a_fat == ano_alvo:
            filtradas.append(t)
            
    return filtradas


def projetar_faturas_futuras(transacoes_do_perfil, cartao_id, qtd_meses=6):
    """
    Projeta o valor das faturas de um cartão específico para os próximos N meses,
    levando em consideração compras à vista, parceladas e o dia de fechamento.
    Retorna um dicionário ordenado com as chaves (ano, mes) e os valores da fatura.
    """
    hoje = date.today()
    projecoes = {}

    # Inicializa os próximos N meses com valor zero
    for i in range(qtd_meses):
        mes_alvo = hoje + relativedelta(months=i)
        chave = (mes_alvo.year, mes_alvo.month)
        projecoes[chave] = 0.0

    for t in transacoes_do_perfil:
        # Filtra apenas transações do cartão selecionado
        c_id = getattr(t, "cartao_id", None)
        if c_id != cartao_id:
            continue
        
        t_dt = getattr(t, "data", None) or getattr(t, "data_dt", None)
        if not t_dt:
            continue

        total_parcelas = max(1, getattr(t, "parcelas", 1))
        valor_parcela = t.valor / total_parcelas

        # Se for parcelado, distribui cada parcela no seu respectivo mês futuro
        for p in range(total_parcelas):
            data_parcela_base = t_dt + relativedelta(months=p)
            chave = (data_parcela_base.year, data_parcela_base.month)

            if chave in projecoes:
                if t.tipo == "Saída":
                    projecoes[chave] += valor_parcela
                elif t.tipo == "Entrada":  # Pagamentos ou estornos abatem
                    projecoes[chave] -= valor_parcela

    return projecoes


def calcular_comprometido(transacoes, dia_fechamento=None, faturas_pagas=None) -> float:
    """
    Valor do limite do cartão que ainda está comprometido.

    Soma as compras (Saída) e subtrai pagamentos/estornos (Entrada) de todas as
    faturas que NÃO estão marcadas como "Paga". `faturas_pagas` é um conjunto de
    tuplas (mes, ano). Ao marcar uma fatura como "Paga", o limite dela é liberado;
    voltando o status para "Aberta"/"Fechada", ele volta a ser comprometido.
    """
    pagas = set(faturas_pagas or [])
    compras = 0.0
    abatimentos = 0.0

    for t in transacoes:
        t_dt = getattr(t, "data", None) or getattr(t, "data_dt", None)
        if t_dt and pagas:
            fatura = obter_mes_ano_fatura(t_dt, dia_fechamento, getattr(t, "tipo", "Saída"))
            if fatura in pagas:
                continue

        if t.tipo == "Saída":
            compras += t.valor
        elif t.tipo == "Entrada":
            abatimentos += t.valor

    return max(0.0, compras - abatimentos)
