"""Regras puras (sem banco de dados) das contas recorrentes."""
import calendar
from datetime import date


def data_vencimento_no_mes(ano: int, mes: int, dia: int) -> date:
    """
    Data de vencimento de uma conta no mês/ano informado.
    Dias 29, 30 ou 31 viram o último dia do mês quando ele não existe (ex.: dia 31 em fevereiro).
    """
    ultimo_dia = calendar.monthrange(ano, mes)[1]
    return date(ano, mes, max(1, min(int(dia), ultimo_dia)))


def calcular_renda_comprometida(renda: float, total_pagas: float, total_pendentes: float) -> dict:
    """
    Quanto da renda do mês está comprometido com contas recorrentes.

    - total_contas: contas pagas + contas a pagar do mês (o "valor" comprometido)
    - livre: o que sobra da renda depois das contas (nunca negativo)
    - percentual: total_contas / renda em % (None quando não há renda lançada)
    """
    total_contas = total_pagas + total_pendentes
    return {
        "renda": renda,
        "pagas": total_pagas,
        "pendentes": total_pendentes,
        "total_contas": total_contas,
        "livre": max(0.0, renda - total_contas),
        "percentual": (total_contas / renda * 100.0) if renda > 0 else None,
    }


def meses_desde(data_inicio: date, ano: int, mes: int) -> int:
    """Quantos meses se passaram entre o mês de início da conta e o mês/ano informado."""
    return (ano - data_inicio.year) * 12 + (mes - data_inicio.month)


def numero_parcela(data_inicio: date, parcela_inicial, total_parcelas, ano: int, mes: int):
    """
    Número da parcela da conta no mês/ano, ou None se a conta ainda não começou
    ou o parcelamento já terminou. Conta sem prazo (total_parcelas vazio) nunca termina.
    """
    indice = meses_desde(data_inicio, ano, mes)
    if indice < 0:
        return None
    numero = (parcela_inicial or 1) + indice
    if total_parcelas and numero > total_parcelas:
        return None
    return numero


def parcelas_restantes(numero, total_parcelas, pago: bool) -> int:
    """Quantas parcelas ainda faltam pagar (a do mês só conta se ainda não foi paga)."""
    if not total_parcelas or numero is None:
        return 0
    return max(0, total_parcelas - numero + (0 if pago else 1))


def calcular_parcela_inicial(data_inicio: date, parcela_mes: int, ano: int, mes: int) -> int:
    """
    Número da parcela no mês de início da conta, sabendo que 'parcela_mes' é o número
    da parcela no mês/ano informado (usado ao editar uma conta em um mês qualquer).
    """
    return parcela_mes - meses_desde(data_inicio, ano, mes)
